
import http from "../http-Common";

class UserService {
  profileCreate(data) {
    return http.post("/User/Profile",data);
  }

  profileUpdate(userID, data) {
    return http.put(`/User/UpdateProfile/${userID}`, data);
  }

  activeDeactiveUserProfile(userID) {
    return http.put(`/User/ActiveDeactiveUserProfile/${userID}`);
  }

  changeUserRole(id, roleID) {
    return http.put(`/User/ChangeUserRole/${id}`, roleID);
  }

  deleteProfileByUserID(id) {
    return http.delete(`/User/DeleteProfileByUserID/${id}`);
  }

  login(email,password) {
    return http.post(`/User/Login/${email}${password}`);
  }

  generateToken(email,password) {
    return http.post(`/User/GenerateToken/${email}${password}`);
  }
}

export default new UserService();