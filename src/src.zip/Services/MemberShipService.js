import http from "../http-Common";

class MemberShip {
    getAllMemberShip() {
    return http.get("/MemberShip/GetAllMemberShip");
  }
}

export default new MemberShip();