import http from "../http-Common";

class CommunityService {

    getAllFirstLevelLookUpData() {
    return http.get("/Site/GetAllFirstLevelLookUpData");
  }

  getAllSecondLevelLookUpData() {
    return http.get("/Site/GetAllSecondLevelLookUpData");
  }

  communitySiteSetUp(data) {
    return http.post("/Site/CommunitySiteSetUp",data);
  }
}

export default new CommunityService();