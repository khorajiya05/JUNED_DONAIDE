
import React, { Component } from "react";
import UserService from "../Services/UserServices";
import CommunityService from "../Services/CommunityService";
import MembershipService from "../Services/MemberShipService";
import validator from 'validator';
 import { useHistory   } from 'react-router-dom';

export default class AddContactInfo extends Component {
  constructor(props) {
    super(props);

    
    // Step1
    this.onChangeFirstName = this.onChangeFirstName.bind(this);
    this.onChangeLastName = this.onChangeLastName.bind(this);
    this.onChangePhone = this.onChangePhone.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangePrivacyPolicy = this.onChangePrivacyPolicy.bind(this);
    this.validateContactInfo = this.validateContactInfo.bind(this);
    this.previousButtonContactInfo = this.previousButtonContactInfo.bind(this);

    // Step2
    this.onChangePassword = this.onChangePassword.bind(this);
    this.onChangeConfirmPassword = this.onChangeConfirmPassword.bind(this);
    this.previousButtonPasswordInfo = this.previousButtonPasswordInfo.bind(this);
    this.validatePasswordInfo = this.validatePasswordInfo.bind(this);

    // Step3
    this.onChangeCommunityName = this.onChangeCommunityName.bind(this);
    this.onChangeCommunityURL = this.onChangeCommunityURL.bind(this);
    this.previousButtonCommunityInfo = this.previousButtonCommunityInfo.bind(this);
    this.validateCommunityInfo = this.validateCommunityInfo.bind(this);

    // Step4
    this.previousButtonCommunityLevel = this.previousButtonCommunityLevel.bind(this);
    this.validateCommunityLevel = this.validateCommunityLevel.bind(this);
    this.selectedfirstLevelValue=this.selectedfirstLevelValue.bind(this);
    this.selectedsecondLevelValue=this.selectedsecondLevelValue.bind(this);

    // Step5
    this.previousButtonSelectPlan = this.previousButtonSelectPlan.bind(this);
    this.validateSelectPlan = this.validateSelectPlan.bind(this);
    this.selectedradiovalue=this.selectedradiovalue.bind(this);
    
    // Final Step
    this.saveContactInfo = this.saveContactInfo.bind(this);
    this.saveCommunityInfo = this.saveCommunityInfo.bind(this);

    this.state = {
      // Step1
      userID: null,
      firstname: "",
      lastname: "",
      phone: "",
      email: "",
      contactsubmitted: false,
      isprivacypolicy: false,
      checked: false,
      roleid: null,
      
      // Step2
      password: "",
      confirmpassword: "",
      passwordsubmitted: false,

      // Step3
      communitysitename: "",
      communitydomain: "",
      communitysubmitted: false,

      // Step4
      allMembershipData : [],


      firstLevelSelectOptions : [],
      secondLevelSelectOptions : [],
      firstlevel:"",
      firstlevelname:"",
      secondlevel:"",
      secondlevelname:"",
      communitylevelsubmitted:false,

      // Step5
      selectedplan : "",
      checkedRadio:false,
      selectedplansubmitted:false,

      // Common Use
      errors: {},
      cssClass1: "",
      cssClass2: "",
      cssClass3: "",
      cssClass4: "",
      borderColorCss:""
      
    };

    // let history = useHistory();

  }

  // Step1
  onChangeFirstName(e) {
    this.setState({
      firstname: e.target.value,
      errors: {}
    });
  }

  onChangeLastName(e) {
    this.setState({
      lastname: e.target.value,
      errors: {}
    });
  }

  onChangePhone(e) {
    this.setState({
      phone: e.target.value.replace(/(\d{3})(\d{3})(\d{4})/,
      '($1) $2-$3'),
      errors: {}
    });
  }

  onChangeEmail(e) {
    this.setState({
      email: e.target.value,
      errors: {}
    });
  }

  onChangePrivacyPolicy(e) {
    this.setState({
      isprivacypolicy: e.target.checked,
      checked: e.target.checked,
      errors: {}
    });
  }

  validateContactInfo() {
    let errors = {};

    if (!this.state.firstname) {
      errors["firstname"] = "Please Enter First Name.";

    }
    else if (!this.state.lastname) {
      errors["lastname"] = "Please Enter Last Name.";
    }
    else if (!this.state.phone) {
      errors["phonenumber"] = "Please Enter Phone Number.";
    }
    else if (this.state.phone.length < 10) {
      errors["phonenumber"] = "Please Enter 10 Digit Phone Number.";
    }
    else if (!this.state.email) {
      errors["email"] = "Please Enter Email.";
    }
    else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(this.state.email)) {
      errors["email"] = "Please Enter Valid Email-ID Like(test@gmail.com)";
    }
    else if (this.state.isprivacypolicy === false) {
      errors["privacypolicy"] = "Please Check Privacy & Policy Checkbox.";
    }
    else {
      errors = {};
      //this.setState({ contactsubmitted: true});
      // {!this.state.contactsubmitted ? this.state.contactsubmitted = true:this.state.contactsubmitted = false} 
       this.state.contactsubmitted = true;
    }

    this.setState({ errors: errors});

    if (this.state.contactsubmitted) {
      //this.setState({ cssClass1: "active"});
       this.state.cssClass1 = "active";
    }

  }

  previousButtonContactInfo() {
    let errors = {};

    var data = {
      firstname: this.state.firstname,
      lastname: this.state.lastname,
      phone: this.state.phone,
      email: this.state.email,
      isprivacypolicy: this.state.isprivacypolicy,
      createddate: new Date(),
      createdby: this.state.firstname,
      isactive: true,
      roleid: 3
    };
    this.setState({ contactsubmitted: false});
    // this.state.contactsubmitted = false
      if (data.isprivacypolicy) {
        //this.setState({ checked: true});
         this.state.checked = true;
      }
      if (!this.state.contactsubmitted) {
        //this.setState({ checked: ""});
         this.state.cssClass1 = "";
      }
    
    this.setState({ errors: errors});
  }

  // Step2
  onChangePassword(e) {
    this.setState({
      password: e.target.value,
      errors: {}
    });
  }

  onChangeConfirmPassword(e) {
    this.setState({
      confirmpassword: e.target.value,
      errors: {}
    });
  }

  validatePasswordInfo() {
    let errors = {};

    if (!this.state.password) {
      errors["password"] = "Please Enter Password.";
    }
    else if (!validator.isStrongPassword(this.state.password, {
      minLength: 8, minLowercase: 1,
      minUppercase: 1, minNumbers: 1, minSymbols: 1
    })) {
       errors["password"] = "Please Enter Valid Password Use(Max Lenght : 8 \n Mininum Lower Case Letters : 1 \n Minimum Upper Case Letters : 1 \n Minimum Numbers : 1 \n Minimum Symbols : 1)";
      //errors["password"] = "Invalid Password";
    }
    else if (!this.state.confirmpassword) {
      errors["confirmpassword"] = "Please Enter Confirm Password.";
    }
    else if (this.state.confirmpassword !== this.state.password) {
      errors["confirmpassword"] = "Confirm Password is not matched with Password.";
    }
    else{
      //this.setState({ passwordsubmitted: true});
       this.state.passwordsubmitted = true;
      errors = {};
    }
    
    this.setState({ errors: errors });

    if (this.state.passwordsubmitted) {
      //this.setState({ cssClass2: "active"});
       this.state.cssClass2 = "active";
    }
  }

  previousButtonPasswordInfo() {
    let errors = {};
    //this.setState({ passwordsubmitted: false});
     this.state.passwordsubmitted = false
      
      if (!this.state.passwordsubmitted) {
        //this.setState({ cssClass2: ""});
         this.state.cssClass2 = "";
      }
    
    this.setState({ errors: errors});
  }

  // Step3
  onChangeCommunityName(e) {
    this.setState({
      communitysitename: e.target.value,
      errors: {}
    });
  }

  onChangeCommunityURL(e) {
    this.setState({
      communitydomain:e.target.value,
      errors: {}
    });
  }

  validateCommunityInfo() {
    let errors = {};

    if (!this.state.communitysitename) {
      errors["communityname"] = "Please Enter Community Name.";
    }
    else if (!/^\S*$/i.test(this.state.communitysitename)) {
      errors["communityname"] = "Not Allow Spaces on Community Name.";
    }
    else{
      //this.setState({ communitysubmitted: true});
       this.state.communitysubmitted = true;
      errors = {};
    }
    
    this.setState({ errors: errors });

    if (this.state.communitysubmitted) {
      //this.setState({ cssClass3: "active"});
       this.state.cssClass3 = "active";
    }
  }

  previousButtonCommunityInfo() {
    let errors = {};

    //this.setState({ communitysubmitted: false});
     this.state.communitysubmitted = false
      
      if (!this.state.communitysubmitted) {
        //this.setState({ cssClass3: ""});
         this.state.cssClass3 = "";
      }
    
    this.setState({ errors: errors});
  }

  // Step4

  // for bind dropdown
  async getFirstLevelOptions(){
    const res = await CommunityService.getAllFirstLevelLookUpData()
    const data = res.data

    const options = data.map(d => ({
      "value" : d._id,
      "label" : d.description
    }))
    this.setState({firstLevelSelectOptions: options})
  }

  async getSecondLevelOptions(){
    const res = await CommunityService.getAllSecondLevelLookUpData()
    const data = res.data

    const options = data.map(d => ({
      "value" : d._id,
      "label" : d.description
    }))
    this.setState({secondLevelSelectOptions: options})
  }

  componentDidMount(){
    this.getFirstLevelOptions()
    this.getSecondLevelOptions()
    this.getMembershipData()
  }


   selectedfirstLevelValue(e) {
    this.setState({ firstlevelname: e.target.value ,firstlevel: e.target.value});
  }

  selectedsecondLevelValue(e) {
    this.setState({ secondlevelname: e.target.value ,secondlevel: e.target.value});
  }

  validateCommunityLevel() {
    let errors = {};

    if (!this.state.firstlevelname) {
      errors["firstlevel"] = "Please Select First Level.";
    }
    else if (!this.state.secondlevelname) {
      errors["secondlevel"] = "Please Select Second Level.";
    }
    else{
      //this.setState({ communitylevelsubmitted: true});
       this.state.communitylevelsubmitted = true;
      errors = {};
    }
    
    this.setState({ errors: errors });

    if (this.state.communitylevelsubmitted) {
      //this.setState({ cssClass4: "active"});
       this.state.cssClass4 = "active";
    }
  }

  previousButtonCommunityLevel() {

    var data = {
      firstlevelname: this.state.firstlevelname,
      firstlevel:this.state.firstlevel,
      secondlevelname: this.state.secondlevelname,
      secondlevel: this.state.secondlevel
    };
    //this.setState({ communitysubmitted: false});
     this.state.communitysubmitted = false
      
      if (!this.state.communitysubmitted) {
        //this.setState({ cssClass3: ""});
         this.state.cssClass3 = "";
      }
    
    this.setState({ data: data});
  }


  // step5

  selectedradiovalue(e) {
    this.setState({ selectedplan: e.target.value });
  }

  validateSelectPlan() {
    let errors = {};

    if (!this.state.selectedplan) {
      errors["selectedPlan"] = "Please Select Any One Plan.";
    }
    else{
      //this.setState({ communitylevelsubmitted: true});
       this.state.communitylevelsubmitted = true;
      errors = {};
    }
    
    this.setState({ errors: errors });
    
    this.saveContactInfo();
  }

  previousButtonSelectPlan() {
    let errors = {};
    // var data = {
    //   firstlevelname: this.state.firstlevelname,
    //   firstlevel:this.state.firstlevel,
    //   secondlevelname: this.state.secondlevelname,
    //   secondlevel: this.state.secondlevel
    // };
    //this.setState({ communitylevelsubmitted: false});
     this.state.communitylevelsubmitted = false
      if (!this.state.communitylevelsubmitted) {
        // this.setState({ cssClass4: ""});
         this.state.cssClass4 = "";
      }

      this.setState({ errors: errors });
  }

  // Final step
  saveContactInfo() {
    var createprofiledata = {
      firstname: this.state.firstname,
      lastname: this.state.lastname,
      phone: this.state.phone,
      email: this.state.email,
      isprivacypolicy: this.state.isprivacypolicy,
      createddate: new Date(),
      createdby: this.state.firstname,
      isactive: true,
      password: this.state.password,
      roleid: 3,
      membershipid:this.state.selectedplan
    };

    UserService.profileCreate(createprofiledata)
    .then(userResponse => {
      this.setState({
        userID: userResponse.data.userID,
        firstname: userResponse.data.firstname,
        lastname: userResponse.data.lastname,
        phone: userResponse.data.phone,
        email: userResponse.data.email,
        isprivacypolicy: userResponse.data.isprivacypolicy,
        createddate: userResponse.data.createddate,
        createdby: userResponse.data.createdby,
        isactive: userResponse.data.isactive,
        roleid: userResponse.data.roleid
      });
      
        this.saveCommunityInfo(userResponse.data.userId);
       
      console.log(userResponse);
    })
    .catch(e => {
      console.log(e);
    });

  }

  saveCommunityInfo(userID) {
    //  let history = useHistory();
    var createcommunitydata = {
      userid:userID,
      communitysitename: this.state.communitysitename,
      communitydomain: this.state.communitydomain +".donaide.com",
      firstlevel: this.state.firstlevel,
      secondlevel: this.state.secondlevelname,
      createddate: new Date(),
      createdby: this.state.firstname,
      isactive: true,
    };

    CommunityService.communitySiteSetUp(createcommunitydata)
    .then(communityResponse => {
      this.setState({
        communitysitename: communityResponse.data.communitysitename,
        communitydomain: communityResponse.data.communitydomain,
        firstlevelname: communityResponse.data.firstlevel,
        secondlevelname: communityResponse.data.secondlevel,
        createddate: new Date(),
        createdby: communityResponse.data.firstname,
        isactive: true,
      });
      console.log(communityResponse.data);
      window.location.assign("/congratulation");
    })
    .catch(e => {
      console.log(e);
    });

  }

  //Common
  async getMembershipData(){
    const res = await MembershipService.getAllMemberShip()
    const data = res.data

    const options = data.map(d => ({
      "_id" : d._id,
      "memberShipName" : d.memberShipName,
      "monthlyPrice" : d.monthlyPrice,
      "noOfCommunity" : d.noOfCommunity,
      "availablefeatures" : d.availableFeatures
    }))
    this.setState({allMembershipData: options})
    console.log(this.state.allMembershipData);
  }

  render() {
    
    return (
      <main className="get-started-bg">

        <div className="main-outer-container">
          <div className="main-inner-container text-center">
            <div className="inner-container-form">
              <div className="inner-container-box">
                <h3 className="main-heading">Start building your community in 5 simple steps</h3>
                {/* Start Main Content section */}
                <form id="msform">
                  {/* progressbar */}
                  <ul id="progressbar">
                    <li className="active" />
                    <li className={this.state.cssClass1} />
                    <li className={this.state.cssClass2}/>
                    <li className={this.state.cssClass3}/>
                    <li className={this.state.cssClass4}/>
                  </ul>
                  {/* progressbar */}
                  {/* fieldsets */}
                  <div className="field-set-outer-box">
                    {
                      (!this.state.contactsubmitted) ? 
                       (

                              <fieldset className="inner-data">
                                <h4 className="main-sub-heading text-center">What's your contact info?</h4>
                                <div className="form-group field-set-form ">

                                  <div className="form-group mb-3">

                                    <input type="text" className="form-control cstm-field"  placeholder="First Name" name="firstname}" value={this.state.firstname}
                                      onChange={this.onChangeFirstName} />
                                    <span style={{ color: "red" }}>{this.state.errors["firstname"]}</span>

                                  </div>

                                  <div className="form-group mb-3">

                                    <input type="text" className="form-control cstm-field" placeholder="Last Name" name="lastname" value={this.state.lastname}
                                      onChange={this.onChangeLastName} />
                                    <span style={{ color: "red" }}>{this.state.errors["lastname"]}</span>
                                  </div>
                                  <div className="form-group mb-3">

                                    <input type="text" className="form-control cstm-field" placeholder="(xxx) - xxxx -xxxx" name="phonenumber" value={this.state.phone}
                                      onChange={this.onChangePhone} />
                                    <span style={{ color: "red" }}>{this.state.errors["phonenumber"]}</span>
                                  </div>
                                  <div className="form-group mb-3">
                                    <input type="email" className="form-control cstm-field" placeholder="Email Address" name="email" value={this.state.email}
                                      onChange={this.onChangeEmail} />
                                    <span style={{ color: "red" }}>{this.state.errors["email"]}</span>
                                  </div>
                                  <div className="term-condition-link">
                                    <div>
                                    <input type="checkbox" className="me-2" checked={this.state.checked} value={this.state.isprivacypolicy} onChange={this.onChangePrivacyPolicy} />I agree to the <a href="/#">Terms and conditions</a> and <a href="/#">Privacy
                                      Policy</a> of donaide plus. </div><span style={{ color: "red" }}>{this.state.errors["privacypolicy"]}</span>
                                  </div>

                                </div>

                                <div className="text-end">
                                  <input type="button" name="next" className="next btn next-button mb-3" defaultValue="Next" onClick={this.validateContactInfo} />
                                </div>
                              </fieldset>

                       ) : (
                        (!this.state.passwordsubmitted)?(

                          <fieldset className="inner-data">
                          <h4 className="main-sub-heading text-center">Create your password</h4>
                          <div className="form-group field-set-form">
                              <div className="form-group mb-3">
                                <input type="password" className="form-control cstm-field" placeholder="Password" name="password" value={this.state.password}
                                  onChange={this.onChangePassword} />
                                <span style={{ color: "red" }}>{this.state.errors["password"]} </span>
                              </div>
                              <div className="form-group mb-3">
                                <input type="password" className="form-control cstm-field" placeholder="Confirm Password" name="confirmpassword" value={this.state.confirmpassword}
                                  onChange={this.onChangeConfirmPassword} />
                                <span style={{ color: "red" }}>{this.state.errors["confirmpassword"]}</span>
                              </div>
                          </div>
                          <div className="text-end">
                            <input type="button" name="previous" className="previous btn previous-button-border " defaultValue="Previous" onClick={this.previousButtonContactInfo} />
                            <input type="button" name="next" className="btn next next-button" defaultValue="Next" onClick={this.validatePasswordInfo} />
                          </div>
                       </fieldset>

                        ) : (

                          (!this.state.communitysubmitted)?(
                            <fieldset className="inner-data">
                          <h4 className="main-sub-heading text-center">Create your community</h4>

                          <div className="form-group field-set-form">
                            <div className="form-group mb-3">
                              <input type="text" className="form-control cstm-field" placeholder="Community Name" name="communityname" value={this.state.communitysitename}
                                onChange={this.onChangeCommunityName} />
                                <span style={{ color: "red" }}>{this.state.errors["communityname"]}</span>
                            </div>
                            <div className="form-group mb-3 community-url-field">
                            <input type="text" className="form-control cstm-field" placeholder="Community URL" name="communityurl" value={this.state.communitydomain}
                                onChange={this.onChangeCommunityURL} />
                                <div className="cstm-url-field">donaide.com</div>
                                <span style={{ color: "red" }}>{this.state.errors["communityurl"]}</span>
                            </div>
                          </div>  
                          <div className="text-end">
                            <input type="button" name="previous" className="previous btn previous-button-border" defaultValue="Previous" onClick={this.previousButtonPasswordInfo}/>
                            <input type="button" name="next" className="btn next next-button" defaultValue="Next" onClick={this.validateCommunityInfo}/>
                          </div>
                      </fieldset>
                          ):(!this.state.communitylevelsubmitted?(
                                  <fieldset className="inner-data">
                                    <h4 className="main-sub-heading text-center">Choose your community category</h4>
                                    
                                   
                                      <div className="form-group field-set-form">
                                        <div class="cstm-field-dropdown mb-3">
                                          <div class="select text-left">
                                            <select className="select" value={this.state.firstlevelname} onChange={this.selectedfirstLevelValue}>
                                              {this.state.firstLevelSelectOptions.map((option) => (
                                              <option value={option.value}>{option.label}</option>
                                              ))}
                                            </select>
                                            <span style={{ color: "red" }}>{this.state.errors["firstlevel"]}</span> 
                                          </div>
                                        </div>

                                        <div class="cstm-field-dropdown mb-3">
                                          <div class="select text-left">
                                          <select className="select" value={this.state.secondlevelname} onChange={this.selectedsecondLevelValue}>
                                            {this.state.secondLevelSelectOptions.map((option) => (
                                            <option value={option.value}>{option.label}</option>
                                            ))}
                                          </select>
                                          <span style={{ color: "red" }}>{this.state.errors["secondlevel"]}</span>  
                                          </div>
                                        </div>
                                      </div>

                                    <div className="text-end">
                                    <input type="button" name="previous" className="previous btn previous-button-border" defaultValue="Previous" onClick={this.previousButtonCommunityLevel}/>
                                    <input type="button" name="next" className="btn next next-button" defaultValue="Next" onClick={this.validateCommunityLevel}/>
                                    </div>
                                  </fieldset>

                            ) : (
                              <fieldset className="inner-data">
                                <h4 className="main-sub-heading text-center">
                                Choose your plan now and start building your community
                                </h4>
                                <div className="form-group field-set-form">
                                  <div className="community-plan-accordion" id="selectcommunityplan">

                                    {this.state.allMembershipData.map((data) => (
                                        <div className="card">
                                        <div className="card-header">
                                          <div className="custom-control custom-radio">
                                            
                                            <div className="plan-card-header">
                                              <input data-bs-toggle="collapse" data-bs-target={"#collapse"+data._id} type="radio" 
                                              id="customRadio1" name="customRadio" value={data._id} className="form-check-input" checked={this.state.selectedplan === data._id} onChange={this.selectedradiovalue}/>
                                              <label className="custom-control-label" htmlFor="customRadio1">
                                                <sup>$</sup>
                                                {data.monthlyPrice}
                                                <span>/month</span>
                                              </label>

                                            </div>

                                            <div className="card-header-prg">
                                              <p>{data.noOfCommunity} site</p>
                                            </div>
                                            
                                          </div>
                                        </div>
                                        <div
                                          id={"collapse"+data._id}
                                          className="collapse"
                                          data-bs-parent="#selectcommunityplan"
                                        >
                                          <div className="card-body">
                                            <p>
                                              <i className="fa fa-check" aria-hidden="true" /> {data.noOfCommunity}
                                              site with limited features.
                                            </p>
                                            <p>
                                              <i className="fa fa-check" aria-hidden="true" /> Lorem Ipsum is
                                              simply dummy.
                                            </p>
                                            <p>
                                              <i className="fa fa-check" aria-hidden="true" /> Lorem Ipsum.
                                            </p>
                                            <p>
                                              <i className="fa fa-check" aria-hidden="true" /> Lorem Ipsum is
                                              simply.
                                            </p>
                                            <p>
                                              <i className="fa fa-check" aria-hidden="true" /> Lorem Ipsum.
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                        ))}
                                  </div>
                                </div>
                                <div className="text-end">
                                  <input
                                  type="button"
                                  name="previous"
                                  className="previous btn previous-button-border"
                                  defaultValue="Previous" onClick={this.previousButtonSelectPlan}
                                  />
                                  <input
                                  type="button"
                                  name="button"
                                  className="btn submit next-button"
                                  defaultValue="Select Plan" onClick={this.validateSelectPlan}
                                  />
                                </div>
                              </fieldset>
                          
                            )
                          )
                        )
                    )}
                  </div>
                </form>
              </div>
              {/* End Main Content section */}
            </div>
          </div>
        </div>
      </main>
    )
  }
}


