import React from "react";
import Award from  "../Assests/Images/award.png";

 

export  const Congratulation = () => {

    return(
<div>
<main class="get-started-bg">
            <div class="main-outer-container">
        
        
 


<div className="curve-up"></div>
<div className="award-image">
<img src={Award} alt="congratulation" />
</div>

<div className="congratulation-box text-center">
    <h1 className="cong-heading">THANK YOU</h1>
    <h3>for setting up an account!</h3>
    <p>We love to have you and we're excited for you to build your Community</p>

    
              <button
                type="button"
                name="next"
                className="btn  let-get-rock-btn"
                defaultValue="Next"
              >Let's Get Rock</button>
</div>


</div>
        </main>
        </div>
    )
}

export default Congratulation;