import React from "react";


import logo from  "../Assests/Images/donaide-logo.svg";


export const Header = () => {
      return(
        <div>
        <nav className="navbar navbar-expand-md  fixed-top " id="top-nav-header">
          <a className="navbar-brand " href="/#">
            <img src={logo} width={140} alt="logo" />
          </a>
          <button className="navbar-toggler " type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
             <i className="fa fa-bars fa-1x" aria-hidden="true" /> 
            {/* <span class="navbar-toggler-icon"></span> */}
            {/* <i class="fa fa-bars" aria-hidden="true"></i> */}
          </button>
          <div className="collapse navbar-collapse" id="collapsibleNavbar">
            <ul className="navbar-nav get-started-links ms-auto ">
              <li className="nav-item ">
                <a className="nav-link" href="/#">
                  Home
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="/#">
                  About Us
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="/#">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>
        </nav>
        
      
        </div>
     
      )
  }
  
  export default Header;
