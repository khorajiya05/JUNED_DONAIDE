import React, { useEffect, useRef, useState } from "react";
import {useNavigate } from 'react-router-dom';
import Test from '../Component/Test';

const CommunityInfo = (props) => {

  const [communityName, setCommunityName] = useState('');
  const [communityUrl, setCommunityUrl] = useState('');
  const [isBack, setBack] = useState(false);
  
  const [validation, setValidation] = useState({
    communityname: '',
    communityurl: ''
  });

  const childRef = useRef();
  let history = useNavigate();

  const handleInputCommunityName = (e) => {
    setCommunityName(e.target.value);
  }

  const handleInputCommunityUrl = (e) => {
    setCommunityUrl(e.target.value);
  }

  const validateCommunityInfo = () => {
    let error=validation
    if (!communityName) {
      error.communityname = "Please Enter Community Name.";
    }
    else if (!communityUrl) {
      error.communityurl = "Please Enter Community URL.";
    }
    else{
      setValidation("");
      setBack(true);
      history('/test');
      
    }
    setValidation(error);
    setBack(false);
  }
  
return(

<fieldset className="inner-data">
                <h4 className="main-sub-heading text-center">Create your community</h4>
                <div className="form-group field-set-form">
                  <div className="form-group">
                    <input type="text" className="form-control cstm-field" placeholder="Community Name" name="communityname" 
                    onChange={handleInputCommunityName} value={communityName}/>
                    <span style={{ color: "red" }}>{(!communityName)?(validation.communityname):(validation.communityname)}</span>
                  </div>
                  <div className="form-group">
                    <input type="text" className="form-control cstm-field" placeholder="Community URL" name="communityurl" 
                    onChange={handleInputCommunityUrl} value={communityUrl} />
                    <span style={{ color: "red" }}>{validation.communityurl}</span>
                  </div>
                </div>  
                <div className="text-right">
                  <input type="button" name="previous" className="previous btn previous-button-border" defaultValue="Previous"/>
                  <input type="button" name="next" className="btn next next-button" defaultValue="Next" onClick={e => validateCommunityInfo(e)}/>
                </div>
                <Test communityName={communityName} communityUrl={communityUrl} isBack={isBack} />
              </fieldset>

)
}

export default CommunityInfo