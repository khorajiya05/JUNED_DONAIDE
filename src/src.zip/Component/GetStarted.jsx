import React from "react";
 import {Link} from 'react-router-dom';

export const GetStarted = () => {

    return(
<div>
<main class="get-started-bg">
            <div class="main-outer-container">
                <div class="home-banner-image">
                </div>
                <div class="main-inner-container text-center">
                    <p class="get-started-prg">We help innovators to successfully build and launch new community
                        website and members app</p>
                    <Link to="/ContactInfo" class="btn btn-get-started">Get Started <i class="fa fa-long-arrow-right ml-2"
                            aria-hidden="true"></i></Link>
                </div>
            </div>
        </main>
        </div>
    )
}

export default GetStarted;