import React, { useState } from "react";
import {useNavigate } from 'react-router-dom';

const Test = (props, ref) => {

    const communityname1=props.communityName;
    const [communityname, setcommunityname] = useState('');
    const [communityurl, setcommunityurl] = useState('');
    const [validation, setValidation] = useState({
      communityname: '',
      communityurl: ''
    });
  
    let history = useNavigate();
  
    const validateCommunityInfo = () => {
      let error=validation
      if (!communityname) {
        error.communityname = "Please Enter Community Name.";
      }
      else if (!communityurl) {
        error.communityurl = "Please Enter Community URL.";
      }
      else{
        setValidation("");
        history("/contactInfo")
      }
  
      setValidation(error);
    }
  
  return(
<div class="container mt-3">
  <h2>Simple Collapsible</h2>
  <p>Click on the button to toggle between showing and hiding content.</p>
  <button type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#demo">Simple collapsible</button>
  <div id="demo" class="collapse">
    Lorem ipsum dolor sit 
  </div>
</div>
  
  )
}
  
export default Test;